#!/bin/sh
set -e

BINDIR="${DESTDIR:-}/usr/local/bin"
DESKTOPDIR="${DESTDIR:-}/usr/share/applications"
ICONDIR512="${DESTDIR:-}/usr/share/icons/hicolor/512x512/apps"
ICONDIR2X="${DESTDIR:-}/usr/share/icons/hicolor/512x512@2/apps"

install -Dm755 ctrl-c "$BINDIR/ctrl-c"
install -Dm644 Ctrl+C.desktop "$DESKTOPDIR/Ctrl+C.desktop"
install -Dm644 ctrl-c.png "$ICONDIR512/ctrl-c.png"
install -Dm644 ctrl-c.png "$ICONDIR2X/ctrl-c.png"

if [ -z "$DESTDIR" ]; then
    if command -v gtk-update-icon-cache >/dev/null 2>&1; then
        gtk-update-icon-cache /usr/share/icons/hicolor/ 2>/dev/null || true
    fi
    echo "Installed Ctrl+C v0.1.0 — run 'ctrl-c' to start"
fi
