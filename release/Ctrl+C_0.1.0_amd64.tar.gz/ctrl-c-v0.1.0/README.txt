Ctrl+C v0.1.0 — Cross-Platform Clipboard Manager

Contents:
  ctrl-c                Binary (16MB, dynamically linked)
  ctrl-c.png            App icon (512x512)
  Ctrl+C.desktop        Desktop entry
  install.sh            Install script
  README.txt            This file

Install:
  sudo ./install.sh
  Uninstall: sudo rm /usr/local/bin/ctrl-c /usr/share/applications/Ctrl+C.desktop
             /usr/share/icons/hicolor/512x512/apps/ctrl-c.png
             /usr/share/icons/hicolor/512x512@2/apps/ctrl-c.png

Runtime dependencies (install via your package manager):
  - libgtk-3-0          (gtk3 on Arch, libgtk-3 on Fedora)
  - libwebkit2gtk-4.1-0 (webkitgtk-6.0 on Arch, webkitgtk6.0 on Fedora)
  - libayatana-appindicator3-1  (libayatana-appindicator on Arch/Fedora)
  - librsvg2-2          (librsvg on Arch/Fedora)
  - xdotool             (optional — enables auto-paste after copy)
